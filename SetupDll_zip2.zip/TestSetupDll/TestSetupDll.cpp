// TestSetupDll.cpp : Defines the entry point for the application.
//
#pragma warning ( disable : 4068 4209 )

#include "stdafx.h"

typedef UINT (*PFN_unzipFileWithPath)(TCHAR* str, TCHAR* strDir);
typedef UINT (*PFN_Install_Init) ( HWND hwndParent, BOOL fFirstCall, BOOL fPreviouslyInstalled, LPCTSTR pszInstallDir );
typedef UINT (*PFN_Install_Exit) ( HWND    hwndParent,
    LPCTSTR pszInstallDir,
    WORD    cFailedDirs,
    WORD    cFailedFiles,
    WORD    cFailedRegKeys,
    WORD    cFailedRegVals,
    WORD    cFailedShortcuts
);

int WINAPI WinMain(	HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPTSTR    lpCmdLine,
					int       nCmdShow)
{
 	// TODO: Place code here.
	//MessageBox(NULL, L"Press OK to continue", L"TestDLL", MB_TOPMOST | MB_SETFOREGROUND);
	HINSTANCE hLib = LoadLibrary(L"\\SetupDLL_zip2.dll");
	PFN_unzipFileWithPath unzipFileWithPath = NULL;
	PFN_Install_Init Install_Init = NULL;
	PFN_Install_Exit Install_Exit = NULL;
	if (hLib!=NULL){
		Install_Init = (PFN_Install_Init) GetProcAddress(hLib, L"Install_Init");
		if (Install_Init!=NULL)
			Install_Init(NULL, TRUE, FALSE, L"\\Temp");

		Install_Exit = (PFN_Install_Exit) GetProcAddress(hLib, L"Install_Exit");
		if (Install_Exit!=NULL)
			Install_Exit(NULL, L"\\Temp", 0,0,0,0,0);
/*
		unzipFileWithPath = (PFN_unzipFileWithPath) GetProcAddress(hLib, _T("unzipFileWithPath"));
		if (unzipFileWithPath != NULL)
			unzipFileWithPath(L"\\test.zip", L"\\");
*/
	}
	else
		DEBUGMSG(1, (L"Could not load library. Last error code=%u", GetLastError()));
	FreeLibrary(hLib);


	return 0;
}

